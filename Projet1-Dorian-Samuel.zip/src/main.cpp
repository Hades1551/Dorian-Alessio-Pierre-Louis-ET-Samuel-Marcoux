//Programme de test de l'interface matrice par Samuel Marcoux et Dorian Alessio Pierre Louis
//Le programme permet de tester l'entièreté des fonctionnalités de l'interface matrice.(La matrice, les 3 DEL, les 8 boutons, le potentiomètre, l'encodeur et la photocellule)
 
//Librairies necessaires au programme
#include <Arduino.h>
#include <MOMO_RGB_Matrix.h> 
#include <bits_manip.h>
 
#define led1_R 39// Define led 1 rouge
#define led1_V 40// Define led 1 vert
#define led1_B 41// Define led 1 bleu
 
#define led2_R 42// Define led 2 rouge
#define led2_V 43// Define led 2 vert
#define led2_B 44// Define led 2 bleu
 
#define led3_R 45// Define led 3 rouge
#define led3_V 46// Define led 3 vert
#define led3_B 47// Define led 3 bleu
 
#define bA PC6// Define bouton A
#define bB PC4// Define bouton B
#define bC PC5// Define bouton C
 
#define bEncondeur PG5 // Define bouton encodeur
 
#define ENC_CHA_ARD 3 // Define pin de l'encodeur channel A Arduino
#define ENC_CHA PE5   // Define pin de l'encodeur channel A
#define ENC_CHB_ARD 5 // Define pin de l'encodeur channel B Arduino
#define ENC_CHB PE3   // Define pin de l'encodeur channel B
 
#define Pot PH3 // Define pin du potentiomètre
 
#define PHOTOCELL PH4//define de la photocell
#define PHOTOCELLA A7//define de la broche analogique pour la photocell

#define NB_LECTURE 8//define du nombre de lectures pour la photocell et le potentiometre
#define SEUIL_DE_CHANGEMENT 5//define du seuil de changement 

#define bUP PC2// Define bouton UP
#define bDown PC7// Define bouton DOWN
#define bLeft PC1// Define bouton LEFT
#define bRight PC3// Define bouton RIGHT
 
MOMO_RGB_Matrix Matrix;
 
enum Etats//Machine à état pour le programme de test
{
 TESTMATRICE,//État de test de la matrice
 TESTBOUTONS,
 ANIMATIONFANCY, //État de test des boutons
};
 
Etats etatActuel = TESTBOUTONS;//Commence le programme dans la fonctions de test des boutons
 
void allume_del1(int rouge, int vert, int bleu)//Allume la DEL 1 avec les couleurs rouge, vert et bleu
{
analogWrite(led1_R, rouge);
analogWrite(led1_V, vert);
analogWrite(led1_B, bleu);
}
 
void allume_del2(int rouge, int vert, int bleu)//Allume la DEL 2 avec les couleurs rouge, vert et bleu
{
analogWrite(led2_R, rouge);
analogWrite(led2_V, vert);
analogWrite(led2_B, bleu);
}
 
void allume_del3(int rouge, int vert, int bleu)//Allume la DEL 3 avec les couleurs rouge, vert et bleu
{
analogWrite(led3_R, rouge);
analogWrite(led3_V, vert);
analogWrite(led3_B, bleu);
}
 
 
void interface(){
//Affiche l'ensemble des cercles présent sur l'interface
 Matrix.drawCircle(32, 12, 2, Matrix.Color888(255, 255, 255));//UP
 Matrix.drawCircle(32, 22, 2, Matrix.Color888(255, 255, 255));//DOWN
 Matrix.drawCircle(27, 17, 2, Matrix.Color888(255, 255, 255));//LEFT
 Matrix.drawCircle(37, 17, 2, Matrix.Color888(255, 255, 255));//RIGHT
 Matrix.drawCircle(50, 17, 2, Matrix.Color888(255, 0, 0)); //Rouge
 Matrix.drawCircle(58, 17, 2, Matrix.Color888(0, 255, 0)); //bleu
 Matrix.drawCircle(45, 25, 2, Matrix.Color888(0, 0, 255)); //Verte
 
 Matrix.setCursor(38,0);
 Matrix.print("TEST");
 
 Matrix.drawCircle(24, 3, 2, Matrix.Color888(0, 255, 200));//Bouton de l'encodeur
}
 
void afficheChiffre(long valeur, int y, int largeur)// fonction pour afficher une valeur sur la matrice et efface la précedente
{
  // Efface la zone de la voulu 
  Matrix.fillRect(0, y, largeur, 8, Matrix.Color888(0, 0, 0));// Efface un rectangle a un endroit voulu

  Matrix.setTextSize(1);// Définit la taille du texte à 1 
  Matrix.setTextWrap(false);// Désactive le retour à la ligne automatique 
  Matrix.setCursor(1, y);// Met le curseurs a la position voulu
  Matrix.setTextColor(Matrix.Color888(255, 255, 255));// Met la couleur a blanc

  Matrix.print(valeur);// Affiche la valeur sur la matrice 
}

void boutons(){
 
  if(isBitSet(PINC, bUP) == LOW){
   Matrix.fillCircle(32, 12, 2, Matrix.Color888(255, 255, 255));//Si le bouton UP est appuyé, allume le cercle UPen blanc
  } else {
     Matrix.fillRect(31, 11, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle UP
  }
 
 
  if(isBitSet(PINC, bDown) == LOW){
   Matrix.fillCircle(32, 22, 2, Matrix.Color888(255, 255, 255));//Si le bouton DOWN est appuyé, allume le cercle DOWN en blanc
  } else {
     Matrix.fillRect(31, 21, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle UP
  }
 
  if(isBitSet(PINC, bLeft) == LOW){
   Matrix.fillCircle(27, 17, 2, Matrix.Color888(255, 255, 255));//Si le bouton LEFT est appuyé, allume le LEFT cercle en blanc
  } else {
     Matrix.fillRect(26, 16, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle UP
  }
 
  if(isBitSet(PINC, bRight) == LOW){
   Matrix.fillCircle(37, 17, 2, Matrix.Color888(255, 255, 255));//Si le bouton RIGHT est appuyé, allume le cercle RIGHT en blanc
  } else {
     Matrix.fillRect(36, 16, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle UP
  }
 
  if(isBitSet(PINC, bB) == LOW){
   Matrix.fillCircle(50, 17, 2, Matrix.Color888(255, 0, 0));//Si le bouton B est appuyé, allume le cercle B en rouge
   allume_del1(255, 0, 0);//Allume la DEL 1 en rouge
   allume_del2(255, 0, 0);//Allume la DEL 2 en rouge
   allume_del3(255, 0, 0);//Allume la DEL 3 en rouge
  } else {
     Matrix.fillRect(49, 16, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle B
     allume_del1(0, 0, 0);//Éteint la DEL 1
     allume_del2(0, 0, 0);//Éteint la DEL 2
     allume_del3(0, 0, 0);//Éteint la DEL 3
  }
 
 
 
 
  if(isBitSet(PINC, bA) == LOW){
   Matrix.fillCircle(45, 25, 2, Matrix.Color888(0, 0, 255));//Si le bouton A est appuyé, allume le cercle A en vert
   allume_del2(0, 255, 0);//Allume la DEL 2 en vert
   allume_del3(0, 255, 0);//Allume la DEL 3 en vert
  } else {
     Matrix.fillRect(44, 24, 3, 3, Matrix.Color888(0, 0, 0));;//Sinon, efface le cercle A
     allume_del1(0, 0, 0);//Éteint la DEL 1
     allume_del2(0, 0, 0);//Éteint la DEL 2
     allume_del3(0, 0, 0);//Éteint la DEL 3
  }
 
 
 
  if(isBitSet(PINC, bC) == LOW){
   Matrix.fillCircle(58, 17, 2, Matrix.Color888(0, 255, 0));//Si le bouton C est appuyé, allume le cercle C en bleu
   allume_del1(0, 0, 255);//Allume la DEL 1 en bleu
   allume_del2(0, 0, 255);//Allume la DEL 2 en bleu
   allume_del3(0, 0, 255);//Allume la DEL 3 en bleu
  } else {
     Matrix.fillRect(57, 16, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle C
     allume_del1(0, 0, 0);//Éteint la DEL 1
     allume_del2(0, 0, 0);//Éteint la DEL 2
     allume_del3(0, 0, 0);//Éteint la DEL 3
  }
 
 
  if(isBitSet(PING, bEncondeur) == LOW){
   Matrix.fillCircle(24, 3, 2, Matrix.Color888(0, 255, 200));//Si le bouton de l'encodeur est appuyé, allume le cercle de l'encodeur en cyan
  } else {
    Matrix.fillRect(23, 2, 3, 3, Matrix.Color888(0, 0, 0));//Sinon, efface le cercle de l'encodeur
  }
}

bool ChangeVal(int nouvelle, int ancienne)// fonction pour vérifier si une valeur a changé beacoup depuis la dernière lecture
{
  if (abs(nouvelle - ancienne) >= 5)// Vérifie si la différence absolue entre les valeurs est plus grandes que 5
  {
    return true;// Retourne true si la valeur a change
  }

  return false;// Retourne false si la valeur ne change pas
}

volatile long encoderVal = 0; // valeur de l'encodeur
 
void BEncodeur(){
  bool valeurCHB = isBitSet(PINE, ENC_CHB); // lire l'état du channel B
 
  if (!valeurCHB)  // Déterminer le sens de rotation
  {
   encoderVal++;
  } else
    {
      encoderVal--;
    }
}

int lireMoyenne(int broche)// fonction pour lire la moyenne des valeurs analogiques
{
  long somme = 0;// Variable pour stocker la somme des valeurs lues

  for (int i = 0; i < NB_LECTURE; i++)// Boucle pour effectuer un nombre set de lectures sur la broche spécifiée.
  {
    somme += analogRead(broche);// Ajoute la valeur lue sur la broche à la somme totale 
    delay(50); 
  }

  return somme / NB_LECTURE;// Retourne la moyenne des valeurs lues sur la broche 
}

int valPhotocel = 0;
int oldPhotocel = -1;
const int photocellPin = A0;
void photocell()
{
 int photo = lireMoyenne(PHOTOCELLA);// Lire la valeur moyenne de la photocell

  if (ChangeVal(photo, valPhotocel))//  Vérifie si la valeur de la photocell a changé beaucoup depuis la dernière lecture
  {
    valPhotocel = photo;// Met à jour valPhotocel avec la nouvelle valeur lue de la photorésistance pour la prochaine comparaison.

    afficheChiffre(valPhotocel, 22, 25);   // force la lecture a une largeur de 25 bits ou 4 chiffres max

  }
}
 
int valPot = 0; // valeur du potentiometre
int oldPot = -1;
int comptePot = 0;//  Variable pour compter le nombre de lectures du potentiomètre
int positionReference = 0;//
 
void Potentio(){
  int pot = lireMoyenne(PH3);// Lit la valeur moyenne du potentiomètre 

  if (ChangeVal(pot, valPot))// Vérifie si la valeur du potentiomètre a changé beaucoup depuis la dernière lecture
    valPot = pot;// Met à jour valPot avec l'ancienne
  {
    // On affiche la valeur du potentiomètre
    afficheChiffre(valPot, 10, 25);   // largeur 25 bits ou 4 chiffres 

    
  }
}
 
 void ChangementEtat()
{
  if (isBitSet(PING, bEncondeur) == LOW  &&  isBitSet(PINC, bC) == LOW)//si le bouton de l'encodeur et le bouton C sont appuyés, passe à l'état de test de la matrice
  {
    etatActuel = TESTMATRICE;//Passe à l'état de test de la matrice
   
  } else if(isBitSet(PING, bEncondeur) == HIGH)//si le bouton de l'encodeur est relâché, passe à l'état de test des boutons
    {
      etatActuel = TESTBOUTONS;//Passe à l'état de test des boutons
    }
 
 
  if (isBitSet(PING, bEncondeur) == LOW  &&  isBitSet(PINC, bA) == LOW)//si le bouton de l'encodeur et le bouton A sont appuyés, passe à l'état d'animation fancy
  {
    etatActuel = ANIMATIONFANCY;//Passe à l'état d'animation fancy
   
  } else if(isBitSet(PING, bEncondeur) == HIGH)//si le bouton de l'encodeur est relâché, passe à l'état de test des boutons
    {
      etatActuel = TESTBOUTONS;//Passe à l'état de test des boutons
    }
}
 

 
void TestMatrice()
{
  Matrix.fillScreen(Matrix.Color888(255, 0, 0));//Remplit l'écran en rouge
  delay(1500);
  Matrix.fillScreen(Matrix.Color888(0, 0, 255));//Remplit l'écran en vert
  delay(1500);
  Matrix.fillScreen(Matrix.Color888(0, 255, 0));//Remplit l'écran en bleu
  delay(2000);
  Matrix.fillScreen(Matrix.Color888(0, 0, 0));//Efface l'écran
 
  etatActuel = TESTBOUTONS;//Retourne à l'état de test des boutons
  interface();//Affiche l'interface de test des boutons

}
 
 
void TestBoutons()
{
 boutons();//Appelle la fonction boutons
 ChangementEtat();//Appelle la fonction ChangementEtat
 Potentio();//Appelle la fonction Potentio
/*  afficheEnco(); */ //Appelle la fonction afficheEnco
/*  testEnco(); */ //Appelle la fonction testEnco
}


void Animation_Fancy() {
  int i, x = 0, y = 0, w = 64, h = 32; // variable x,y,w,h nécessaire au rectangle de l'animation
 
  for (i = 0; i < 16; i++) // Boucle for pour faire toutes les rectangles de l'animation
  {
    Matrix.drawRect(x, y, w, h, Matrix.Color888(255, 155, 0)); // Draw un rectangle sur la Matrix
     
    x = x + 1; // + 1 sur l'axe de x
    y = y + 1; // + 1 sur l'axe de y
    w = w - 2; // - 2 sur le width
    h = h - 2; // - 2 sur le height
 
    delay(16);
  }
   
  for (i = 0; i < 16; i++) // // Boucle for pour effacer toutes les rectangles de l'animation
  {
    Matrix.drawRect(x, y, w, h, Matrix.Color888(0, 0, 0)); // efface un rectangle sur la Matrix
   
    x = x - 1; // - 1 sur l'axe de x
    y = y - 1; // - 1 sur l'axe de y
    w = w + 2; // + 2 sur le width
    h = h + 2; // + 2 sur le height
     
    delay(16);
  }
 
    for (i = 0; i < 16; i++) // Boucle for pour faire toutes les rectangles de l'animation
  {
    Matrix.drawRect(x, y, w, h, Matrix.Color888(0, 155, 255)); // Draw un rectangle sur la Matrix
     
    x = x + 1; // + 1 sur l'axe de x
    y = y + 1; // + 1 sur l'axe de y
    w = w - 2; // - 2 sur le width
    h = h - 2; // - 2 sur le height
 
    delay(16);
  }
   
  for (i = 0; i < 16; i++) // // Boucle for pour effacer toutes les rectangles de l'animation
  {
    Matrix.drawRect(x, y, w, h, Matrix.Color888(0, 0, 0)); // efface un rectangle sur la Matrix
   
    x = x - 1; // - 1 sur l'axe de x
    y = y - 1; // - 1 sur l'axe de y
    w = w + 2; // + 2 sur le width
    h = h + 2; // + 2 sur le height
     
    delay(16);
  }
 
  Matrix.fillScreen(Matrix.Color888(0, 0, 0));//Efface la matrice    
  etatActuel = TESTBOUTONS;//Retourne à l'état de test des boutons
  interface();
}
 
 
void setup() {
Matrix.begin();//Initialise la matrice
Serial.begin(9600);//Initialise le port série
Matrix.fillScreen(Matrix.Color888(0, 0, 0));//Efface la matrice
Animation_Fancy();
 
DDRG = B11100000;//Configure les pins de la matrice
DDRL = B00111111;//Configure les pins de la matrice
PORTC = B11111111;//Active les résistances de pull-up sur les boutons
 
DDRE &= ~(1 << ENC_CHA); // configure ENC_CHA comme entrée
DDRE &= ~(1 << ENC_CHB); // configure ENC_CHB comme entrée
DDRG &= ~(1 << bEncondeur); // configure bEncondeur comme entrée
DDRH &= ~(1 << Pot); // configure Pot comme entrée

DDRH = clearBit(DDRH, PH4);// Configure la broche de la photocell comme entrée
PORTH = setBit(PORTH, PH4);//// configure les ports  de la photocell comme entrée 

attachInterrupt(1, BEncodeur, RISING);// configure l'interruption pour l'encodeur
// Première lecture des capteurs
valPot = lireMoyenne(PH3);
valPhotocel = lireMoyenne(PH4);
}
 
void loop()//Machine à état pour le programme de test
{
 switch(etatActuel){
   case TESTMATRICE:
    TestMatrice();
     break;
   case TESTBOUTONS:
    TestBoutons();
     break;
   case ANIMATIONFANCY:
    Animation_Fancy();
     break;
 }
}
 